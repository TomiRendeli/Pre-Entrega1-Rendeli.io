const CartWidget = () => {
  return (
<h1>Carrito de compras</h1>  )
}

export default CartWidget;